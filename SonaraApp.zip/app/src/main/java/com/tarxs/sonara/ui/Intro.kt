package com.tarxs.sonara.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tarxs.sonara.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 1. The Sonara logo on a dark cover, which also hides the app while it loads.
 * 2. The cover fades away and the main app is there.
 * 3. A "Welcome!" popup with the name from Settings shows for about a second. It never blocks touches.
 */
@Composable
fun SonaraIntro(onFinished: () -> Unit) {
    val context = LocalContext.current
    val name = remember { savedName(context).trim().ifBlank { "User" } }
    val logo = remember { Animatable(0f) }
    val cover = remember { Animatable(1f) }
    val card = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        logo.animateTo(1f, tween(400))
        delay(900)
        launch { logo.animateTo(0f, tween(350)) }
        cover.animateTo(0f, tween(450))
        card.animateTo(1f, tween(280))
        delay(1000)
        card.animateTo(0f, tween(300))
        onFinished()
    }

    Box(Modifier.fillMaxSize()) {
        if (cover.value > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(cover.value)
                    .background(Color(0xFF001212))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    painter = painterResource(R.drawable.sonara_wordmark_on_dark),
                    contentDescription = "Sonara by TARXS",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .width(280.dp)
                        .alpha(logo.value),
                )
            }
        }
        if (card.value > 0f) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .align(Alignment.Center)
                    .scale(0.92f + 0.08f * card.value)
                    .alpha(card.value)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xE60B1F1F))
                    .padding(horizontal = 40.dp, vertical = 28.dp),
            ) {
                Image(
                    painter = painterResource(R.drawable.sonara_launcher_mono),
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                )
                Text("Welcome!", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light, letterSpacing = 2.sp)
                Text(
                    text = name,
                    color = Color(0xFFDCEBFA),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}
