package com.tarxs.sonara.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SonaraColors = darkColorScheme(
    primary = Color(0xFFB8B8B8),
    onPrimary = Color(0xFF101414),
    secondary = Color(0xFFB8B8B8),
    background = Color(0xFF0E0F10),
    onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF0E0F10),
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF262829),
    onSurfaceVariant = Color(0xFF9AA3A3),
)

@Composable
fun SonaraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SonaraColors, content = content)
}
