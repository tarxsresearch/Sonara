package com.tarxs.sonara

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class ArchiveItem(val identifier: String, val title: String, val creator: String)

/**
 * Free music sources that need no account and no key:
 * - Audius, through its public API
 * - The Internet Archive, through its public search and file listings
 * - Radio Browser, a public directory of internet radio stations
 */
object OnlineSources {
    private const val APP_NAME = "Sonara"
    private var audiusHost: String? = null

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 12000
            setRequestProperty("User-Agent", "Sonara/1.0 (TARXS Industries)")
        }

    private fun getText(url: String): String? = try {
        val connection = open(url)
        try {
            if (connection.responseCode in 200..299) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                null
            }
        } finally {
            connection.disconnect()
        }
    } catch (e: Exception) {
        null
    }

    /** Downloads a small file such as cover art. Call it off the main thread. */
    fun getBytes(url: String): ByteArray? = try {
        val connection = open(url)
        try {
            if (connection.responseCode in 200..299) connection.inputStream.use { it.readBytes() } else null
        } finally {
            connection.disconnect()
        }
    } catch (e: Exception) {
        null
    }

    private fun enc(text: String): String = URLEncoder.encode(text, "UTF-8")

    private fun text(obj: JSONObject, name: String): String =
        when (val value = obj.opt(name)) {
            is JSONArray -> value.optString(0)
            is String -> value
            else -> ""
        }

    // ---- Audius

    private fun audiusBase(): String? {
        audiusHost?.let { return it }
        val body = getText("https://api.audius.co") ?: return null
        return try {
            val hosts = JSONObject(body).getJSONArray("data")
            if (hosts.length() == 0) null else hosts.getString(0).also { audiusHost = it }
        } catch (e: Exception) {
            null
        }
    }

    private fun parseAudius(body: String?, host: String): List<Song> {
        if (body == null) return emptyList()
        return try {
            val array = JSONObject(body).optJSONArray("data") ?: return emptyList()
            val songs = mutableListOf<Song>()
            for (i in 0 until array.length()) {
                val track = array.optJSONObject(i) ?: continue
                if (track.has("is_streamable") && !track.optBoolean("is_streamable", true)) continue
                val id = track.optString("id")
                if (id.isBlank()) continue
                val art = track.optJSONObject("artwork")?.optString("480x480")
                songs += Song(
                    id = 0,
                    title = track.optString("title", "Unknown title"),
                    artist = track.optJSONObject("user")?.optString("name") ?: "Unknown artist",
                    album = "Audius",
                    folder = "Audius",
                    remoteUrl = "$host/v1/tracks/$id/stream?app_name=$APP_NAME",
                    artUrl = art?.takeIf { it.isNotBlank() },
                    source = "Audius",
                )
            }
            songs
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun searchAudius(query: String): List<Song> = withContext(Dispatchers.IO) {
        val host = audiusBase() ?: return@withContext emptyList()
        parseAudius(getText("$host/v1/tracks/search?query=${enc(query)}&limit=15&app_name=$APP_NAME"), host)
    }

    suspend fun audiusTrending(): List<Song> = withContext(Dispatchers.IO) {
        val host = audiusBase() ?: return@withContext emptyList()
        parseAudius(getText("$host/v1/tracks/trending?time=week&limit=12&app_name=$APP_NAME"), host)
    }

    // ---- Radio Browser (free directory of internet radio stations)

    private val radioHosts = listOf(
        "https://de1.api.radio-browser.info",
        "https://de2.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://fi1.api.radio-browser.info",
    )

    private fun radioGet(path: String): String? {
        for (host in radioHosts) {
            val body = getText(host + path)
            if (body != null) return body
        }
        return null
    }

    private fun parseRadio(body: String?): List<Song> {
        if (body == null) return emptyList()
        return try {
            val array = JSONArray(body)
            val stations = mutableListOf<Song>()
            for (i in 0 until array.length()) {
                val station = array.optJSONObject(i) ?: continue
                if (station.has("lastcheckok") && station.optInt("lastcheckok", 1) == 0) continue
                val url = station.optString("url_resolved").ifBlank { station.optString("url") }
                val name = station.optString("name").trim()
                if (url.isBlank() || name.isBlank()) continue
                val tag = station.optString("tags").split(',').firstOrNull { it.isNotBlank() }
                val artist = listOfNotNull(station.optString("country").ifBlank { null }, tag)
                    .joinToString(" \u00b7 ")
                    .ifBlank { "Live radio" }
                stations += Song(
                    id = 0,
                    title = name,
                    artist = artist,
                    album = "Live radio",
                    folder = "Radio",
                    remoteUrl = url,
                    artUrl = station.optString("favicon").takeIf { it.isNotBlank() },
                    source = "Radio",
                )
            }
            stations
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun searchRadio(query: String): List<Song> = withContext(Dispatchers.IO) {
        parseRadio(
            radioGet("/json/stations/search?name=${enc(query)}&limit=15&hidebroken=true&order=clickcount&reverse=true")
        )
    }

    suspend fun radioTop(): List<Song> = withContext(Dispatchers.IO) {
        parseRadio(radioGet("/json/stations/topclick/12?hidebroken=true"))
    }

    // ---- Internet Archive

    suspend fun searchArchive(query: String): List<ArchiveItem> = withContext(Dispatchers.IO) {
        val q = enc("($query) AND mediatype:audio")
        val body = getText(
            "https://archive.org/advancedsearch.php?q=$q&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator" +
                "&rows=15&output=json&sort%5B%5D=downloads+desc"
        ) ?: return@withContext emptyList()
        try {
            val docs = JSONObject(body).getJSONObject("response").getJSONArray("docs")
            val items = mutableListOf<ArchiveItem>()
            for (i in 0 until docs.length()) {
                val doc = docs.optJSONObject(i) ?: continue
                val id = doc.optString("identifier")
                if (id.isBlank()) continue
                items += ArchiveItem(id, text(doc, "title").ifBlank { id }, text(doc, "creator"))
            }
            items
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun archiveTracks(item: ArchiveItem): List<Song> = withContext(Dispatchers.IO) {
        val body = getText("https://archive.org/metadata/${item.identifier}") ?: return@withContext emptyList()
        try {
            val files = JSONObject(body).optJSONArray("files") ?: return@withContext emptyList()
            val mp3 = mutableListOf<JSONObject>()
            for (i in 0 until files.length()) {
                val file = files.optJSONObject(i) ?: continue
                if (file.optString("format").contains("MP3", ignoreCase = true) &&
                    !file.optString("name").endsWith(".m3u", ignoreCase = true)
                ) {
                    mp3 += file
                }
            }
            val preferred = mp3.filter { it.optString("format").contains("VBR", ignoreCase = true) }.ifEmpty { mp3 }
            preferred.take(40).map { file ->
                val name = file.optString("name")
                Song(
                    id = 0,
                    title = file.optString("title").ifBlank { name.substringAfterLast('/').substringBeforeLast('.') },
                    artist = item.creator.ifBlank { "Unknown artist" },
                    album = item.title,
                    folder = "Internet Archive",
                    remoteUrl = "https://archive.org/download/${item.identifier}/" +
                        name.split('/').joinToString("/") { enc(it).replace("+", "%20") },
                    artUrl = "https://archive.org/services/img/${item.identifier}",
                    source = "Internet Archive",
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
