package com.tarxs.sonara.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.tarxs.sonara.R
import com.tarxs.sonara.Song
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    songs: List<Song>,
    trending: List<Song>,
    radio: List<Song>,
    ui: PlaybackUi,
    player: Player?,
    onSettings: () -> Unit,
) {
    // The carousel shows your own music first, and Audius trending when the phone has none.
    val featured = remember(songs, trending) { (if (songs.isNotEmpty()) songs else trending).take(6) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 190.dp),
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 22.dp, end = 14.dp, top = 14.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    painter = painterResource(R.drawable.sonara_wordmark_on_dark),
                    contentDescription = "Sonara by TARXS",
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.CenterStart,
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp),
                )
                FilledTonalIconButton(onClick = onSettings, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Rounded.Build, contentDescription = "Settings")
                }
            }
        }
        if (featured.isNotEmpty()) {
            item {
                SonaraCarousel(
                    songs = featured,
                    activeId = ui.item?.mediaId,
                    isPlaying = ui.isPlaying,
                    onPlay = { index ->
                        val id = featured[index].key
                        if (ui.item?.mediaId == id) player?.toggle() else player?.playSongs(featured, index)
                    },
                )
            }
            item {
                Text(
                    text = "Recently added",
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp),
                )
            }
        }
        if (songs.isEmpty() && trending.isEmpty()) {
            item {
                Text(
                    text = "No songs found yet. Add music to your phone, or connect to the internet for free online music.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp),
                )
            }
        }
        itemsIndexed(songs.take(30)) { index, song ->
            SongRow(song, active = ui.item?.mediaId == song.key) {
                player?.playSongs(songs, index)
            }
        }
        if (trending.isNotEmpty()) {
            item {
                Text(
                    text = "Trending on Audius",
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp),
                )
            }
            itemsIndexed(trending) { index, song ->
                SongRow(song, active = ui.item?.mediaId == song.key) {
                    player?.playSongs(trending, index)
                }
            }
        }
        if (radio.isNotEmpty()) {
            item {
                Text(
                    text = "Popular radio",
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 6.dp),
                )
            }
            itemsIndexed(radio) { index, song ->
                SongRow(song, active = ui.item?.mediaId == song.key) {
                    player?.playSongs(radio, index)
                }
            }
        }
    }
}

/** Swipeable carousel. It slides on by itself every 2 seconds, always forward, and waits while touched. */
@Composable
fun SonaraCarousel(
    songs: List<Song>,
    activeId: String?,
    isPlaying: Boolean,
    onPlay: (Int) -> Unit,
) {
    val count = songs.size
    val loop = count > 1
    val pagerState = rememberPagerState(
        initialPage = if (loop) 5000 - 5000 % count else 0,
        pageCount = { if (loop) 10_000 else 1 },
    )
    val current = pagerState.currentPage % count

    LaunchedEffect(pagerState.currentPage, pagerState.isScrollInProgress, count) {
        if (loop && !pagerState.isScrollInProgress) {
            delay(2000)
            pagerState.animateScrollToPage(pagerState.currentPage + 1)
        }
    }

    Column(Modifier.fillMaxWidth()) {
        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = 24.dp),
            pageSpacing = 12.dp,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
        ) { page ->
            val index = page % count
            val song = songs[index]
            val active = song.key == activeId
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(22.dp))
                    .clickable { onPlay(index) },
            ) {
                SongArt(song, Modifier.fillMaxSize(), corner = 22.dp)
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                0.4f to Color.Transparent,
                                1f to Color.Black.copy(alpha = 0.75f),
                            )
                        )
                )
                Row(
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = Color.White,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = song.artist,
                            color = Color.White.copy(alpha = 0.75f),
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFB8B8B8)),
                    ) {
                        Icon(
                            imageVector = if (active && isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black,
                        )
                    }
                }
            }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 10.dp),
        ) {
            repeat(count) { i ->
                val on = i == current
                Box(
                    Modifier
                        .size(width = if (on) 18.dp else 6.dp, height = 6.dp)
                        .clip(CircleShape)
                        .background(
                            if (on) MaterialTheme.colorScheme.onSurface
                            else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                        )
                )
            }
        }
    }
}
