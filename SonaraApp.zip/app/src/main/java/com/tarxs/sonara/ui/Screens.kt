package com.tarxs.sonara.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.tarxs.sonara.ArchiveItem
import com.tarxs.sonara.OnlineSources
import com.tarxs.sonara.Song
import com.tarxs.sonara.SongRegistry

private val ListPadding = PaddingValues(bottom = 190.dp)

@Composable
fun SongsScreen(songs: List<Song>, ui: PlaybackUi, player: Player?) {
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = ListPadding) {
        item {
            Text(
                text = "Songs",
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 10.dp),
            )
        }
        itemsIndexed(songs) { index, song ->
            SongRow(song, active = ui.item?.mediaId == song.key) { player?.playSongs(songs, index) }
        }
    }
}

@Composable
fun SearchScreen(songs: List<Song>, ui: PlaybackUi, player: Player?, onSearched: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    val local = remember(songs, query) {
        if (query.isBlank()) emptyList()
        else songs.filter {
            it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true)
        }
    }
    var audius by remember { mutableStateOf<List<Song>>(emptyList()) }
    var archive by remember { mutableStateOf<List<ArchiveItem>>(emptyList()) }
    var radio by remember { mutableStateOf<List<Song>>(emptyList()) }
    var previews by remember { mutableStateOf<List<Song>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Online search starts half a second after you stop typing.
    LaunchedEffect(query) {
        if (query.isBlank()) {
            audius = emptyList()
            archive = emptyList()
            radio = emptyList()
            previews = emptyList()
            loading = false
            return@LaunchedEffect
        }
        loading = true
        delay(500)
        val music = async { OnlineSources.searchAudius(query.trim()) }
        val items = async { OnlineSources.searchArchive(query.trim()) }
        val stations = async { OnlineSources.searchRadio(query.trim()) }
        val clips = async { OnlineSources.searchPreviews(query.trim()) }
        audius = music.await()
        archive = items.await()
        radio = stations.await()
        previews = clips.await()
        SongRegistry.put(audius + radio + previews)
        loading = false
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Search songs, albums, artists") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSearched(query) }),
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp),
        )
        LazyColumn(contentPadding = ListPadding) {
            if (local.isNotEmpty()) {
                item { SectionTitle("On your phone") }
                itemsIndexed(local) { index, song ->
                    SongRow(song, active = ui.item?.mediaId == song.key) { onSearched(query); player?.playSongs(local, index) }
                }
            }
            if (audius.isNotEmpty()) {
                item { SectionTitle("Audius") }
                itemsIndexed(audius) { index, song ->
                    SongRow(song, active = ui.item?.mediaId == song.key) { onSearched(query); player?.playSongs(audius, index) }
                }
            }
            if (previews.isNotEmpty()) {
                item { SectionTitle("Famous songs (30-second previews)") }
                itemsIndexed(previews) { index, song ->
                    SongRow(song, active = ui.item?.mediaId == song.key) { onSearched(query); player?.playSongs(previews, index) }
                }
            }
            if (radio.isNotEmpty()) {
                item { SectionTitle("Radio") }
                itemsIndexed(radio) { index, song ->
                    SongRow(song, active = ui.item?.mediaId == song.key) { onSearched(query); player?.playSongs(radio, index) }
                }
            }
            if (archive.isNotEmpty()) {
                item { SectionTitle("Internet Archive") }
                items(archive) { entry ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    onSearched(query)
                                    val tracks = OnlineSources.archiveTracks(entry)
                                    SongRegistry.put(tracks)
                                    player?.playSongs(tracks, 0)
                                }
                            }
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                    ) {
                        Text(entry.title, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (entry.creator.isNotBlank()) {
                            Text(
                                text = entry.creator,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            if (query.isNotBlank()) {
                item {
                    val message = when {
                        loading -> "Searching\u2026"
                        local.isEmpty() && audius.isEmpty() && archive.isEmpty() && radio.isEmpty() && previews.isEmpty() -> "Nothing found."
                        else -> null
                    }
                    if (message != null) {
                        Text(
                            text = message,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp),
    )
}

private enum class Grouping(val label: String) { Albums("Albums"), Artists("Artists"), Folders("Folders") }

/** Library groups the songs by album, artist or folder. Folders live here, not in a tab of their own. */
@Composable
fun LibraryScreen(songs: List<Song>, player: Player?) {
    var grouping by rememberSaveable { mutableStateOf(Grouping.Folders) }
    val groups = remember(songs, grouping) {
        when (grouping) {
            Grouping.Albums -> songs.groupBy { it.album }
            Grouping.Artists -> songs.groupBy { it.artist }
            Grouping.Folders -> songs.groupBy { it.folder }
        }.toList().sortedBy { it.first.lowercase() }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text(
            text = "Library",
            fontSize = 26.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 10.dp),
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
        ) {
            Grouping.entries.forEach { option ->
                FilterChip(
                    selected = grouping == option,
                    onClick = { grouping = option },
                    label = { Text(option.label) },
                )
            }
        }
        LazyColumn(contentPadding = ListPadding) {
            items(groups) { (name, members) ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clickable { player?.playSongs(members, 0) }
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    Text(name, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(
                        text = "${members.size} songs",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun ChatScreen() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Rounded.Send,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(56.dp),
        )
        Text("Chat", fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
        Text(
            text = "This feature is coming soon.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Text("Sonara needs access to your music", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(
            text = "Allow access to audio files so Sonara can find and play the songs on your phone.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Button(onClick = onRequest) { Text("Allow access") }
    }
}
