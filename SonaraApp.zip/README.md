# Sonara

Sonara by TARXS Industries: a music player for the songs on your phone.

- Logo start-up, then the app, then a Welcome popup with the name you set in Settings
- Swipe carousel that slides on by itself every 2 seconds
- Home, Songs, Search, Library (Albums, Artists, Folders) and a Chat tab (coming soon)
- Free online music from Audius, the Internet Archive and Radio Browser (no account, no key)
- Floating rounded bottom bar, mini player and full player
- Background playback with notification controls

Build: `gradle assembleDebug` (Gradle 8.11, JDK 17 or newer, Android SDK 35).
