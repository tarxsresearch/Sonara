package com.tarxs.sonara

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val folder: String,
    /** Set for songs from an online source. Local songs leave it null. */
    val remoteUrl: String? = null,
    val artUrl: String? = null,
    val source: String = "Phone",
) {
    /** Identifies the song everywhere: the media id while it plays, and the cover-art cache key. */
    val key: String
        get() = remoteUrl ?: id.toString()

    val uri: Uri
        get() = if (remoteUrl != null) {
            Uri.parse(remoteUrl)
        } else {
            ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        }
}

/** Every song the screens have shown, so the player can find a playing song by its media id. */
object SongRegistry {
    private val songs = HashMap<String, Song>()

    fun put(list: List<Song>) {
        list.forEach { songs[it.key] = it }
    }

    fun get(key: String?): Song? = key?.let { songs[it] }
}

/** Reads the music stored on the phone from Android's media database. */
object MusicRepository {
    @Suppress("DEPRECATION")
    fun load(context: Context): List<Song> {
        val songs = mutableListOf<Song>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DATA,
        )
        val cursor = context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.DATE_ADDED} DESC",
        ) ?: return songs
        cursor.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            while (c.moveToNext()) {
                val artist = c.getString(artistCol)
                val album = c.getString(albumCol)
                val path = c.getString(dataCol)
                songs += Song(
                    id = c.getLong(idCol),
                    title = c.getString(titleCol) ?: "Unknown title",
                    artist = if (artist.isNullOrBlank() || artist == "<unknown>") "Unknown artist" else artist,
                    album = if (album.isNullOrBlank()) "Unknown album" else album,
                    folder = path?.let { File(it).parentFile?.name } ?: "Unknown folder",
                )
            }
        }
        return songs
    }
}

/** Takes one song from each list in turn, so no single list fills the result. */
fun mixLists(vararg lists: List<Song>, limit: Int): List<Song> {
    val result = mutableListOf<Song>()
    var i = 0
    while (result.size < limit && lists.any { i < it.size }) {
        for (list in lists) {
            if (i < list.size && result.size < limit) result += list[i]
        }
        i++
    }
    return result.distinctBy { it.key }
}
