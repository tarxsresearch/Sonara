package com.tarxs.sonara.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tarxs.sonara.OnlineSources
import com.tarxs.sonara.Song
import com.tarxs.sonara.SongRegistry

private enum class NavTab(val label: String, val icon: ImageVector) {
    Home("Home", Icons.Rounded.Home),
    Songs("Songs", Icons.Rounded.MusicNote),
    Search("Search", Icons.Rounded.Search),
    Library("Library", Icons.Rounded.LibraryMusic),
    Chat("Chat", Icons.AutoMirrored.Rounded.Send),
}

@Composable
fun SonaraApp(songs: List<Song>, hasPermission: Boolean, onRequestPermission: () -> Unit) {
    val player = rememberPlayer()
    val ui = rememberPlaybackUi(player)
    var tab by rememberSaveable { mutableStateOf(NavTab.Home) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showNowPlaying by rememberSaveable { mutableStateOf(false) }
    var trending by remember { mutableStateOf<List<Song>>(emptyList()) }
    var radio by remember { mutableStateOf<List<Song>>(emptyList()) }

    LaunchedEffect(songs) { SongRegistry.put(songs) }
    LaunchedEffect(Unit) {
        trending = OnlineSources.audiusTrending()
        SongRegistry.put(trending)
    }
    LaunchedEffect(Unit) {
        radio = OnlineSources.radioTop()
        SongRegistry.put(radio)
    }

    BackHandler(enabled = showNowPlaying) { showNowPlaying = false }
    BackHandler(enabled = showSettings && !showNowPlaying) { showSettings = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (!hasPermission) {
            PermissionScreen(onRequestPermission)
        } else {
            when (tab) {
                NavTab.Home -> HomeScreen(songs, trending, radio, ui, player, onSettings = { showSettings = true })
                NavTab.Songs -> SongsScreen(songs, ui, player)
                NavTab.Search -> SearchScreen(songs, ui, player)
                NavTab.Library -> LibraryScreen(songs, player)
                NavTab.Chat -> ChatScreen()
            }
        }

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            MiniPlayer(songs, ui, player, onOpen = { showNowPlaying = true })
            Dock(selected = tab, onSelect = { tab = it })
        }

        if (showSettings) SettingsScreen(onClose = { showSettings = false })
        if (showNowPlaying) NowPlayingScreen(songs, ui, player, onClose = { showNowPlaying = false })
    }
}

/** The bottom bar: a floating card with rounded corners. */
@Composable
private fun Dock(selected: NavTab, onSelect: (NavTab) -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = Color(0xFF1D2021),
        shadowElevation = 8.dp,
        modifier = Modifier
            .padding(horizontal = 12.dp)
            .fillMaxWidth()
            .height(64.dp),
    ) {
        Row5(selected, onSelect)
    }
}

@Composable
private fun Row5(selected: NavTab, onSelect: (NavTab) -> Unit) {
    androidx.compose.foundation.layout.Row(Modifier.fillMaxSize()) {
        NavTab.entries.forEach { item ->
            val on = item == selected
            val color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable { onSelect(item) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(item.icon, contentDescription = item.label, tint = color, modifier = Modifier.size(22.dp))
                Text(item.label, fontSize = 10.sp, color = color)
            }
        }
    }
}
