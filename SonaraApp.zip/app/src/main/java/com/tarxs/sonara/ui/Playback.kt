package com.tarxs.sonara.ui

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.tarxs.sonara.OnlineSources
import com.tarxs.sonara.PlaybackService
import com.tarxs.sonara.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** What the screens need to know about playback right now. */
@Stable
class PlaybackUi {
    var isPlaying by mutableStateOf(false)
    var item by mutableStateOf<MediaItem?>(null)
    var positionMs by mutableLongStateOf(0L)
    var durationMs by mutableLongStateOf(0L)
}

/** Connects to the background playback service. Null until the connection is ready. */
@Composable
fun rememberPlayer(): Player? {
    val context = LocalContext.current
    var player by remember { mutableStateOf<Player?>(null) }
    DisposableEffect(Unit) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                player = try {
                    future.get()
                } catch (e: Exception) {
                    null
                }
            },
            ContextCompat.getMainExecutor(context),
        )
        onDispose {
            MediaController.releaseFuture(future)
            player = null
        }
    }
    return player
}

@Composable
fun rememberPlaybackUi(player: Player?): PlaybackUi {
    val ui = remember { PlaybackUi() }
    DisposableEffect(player) {
        if (player == null) {
            onDispose { }
        } else {
            fun sync() {
                ui.isPlaying = player.isPlaying
                ui.item = player.currentMediaItem
                ui.durationMs = player.duration.coerceAtLeast(0L)
                ui.positionMs = player.currentPosition
            }
            val listener = object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) {
                    sync()
                }
            }
            player.addListener(listener)
            sync()
            onDispose { player.removeListener(listener) }
        }
    }
    LaunchedEffect(player, ui.isPlaying) {
        if (player != null) {
            while (ui.isPlaying) {
                ui.positionMs = player.currentPosition
                delay(500)
            }
        }
    }
    return ui
}

fun Song.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(key)
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .setArtworkUri(artUrl?.let { android.net.Uri.parse(it) })
                .build()
        )
        .build()

fun Player.playSongs(songs: List<Song>, start: Int) {
    if (songs.isEmpty()) return
    setMediaItems(songs.map { it.toMediaItem() }, start.coerceIn(0, songs.lastIndex), 0L)
    prepare()
    play()
}

fun Player.toggle() {
    if (isPlaying) pause() else play()
}

fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

private object ArtCache {
    val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
}

private fun decodeSampled(data: ByteArray): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(data, 0, data.size, bounds)
    var sample = 1
    while (bounds.outWidth / sample > 800) sample *= 2
    return BitmapFactory.decodeByteArray(data, 0, data.size, BitmapFactory.Options().apply { inSampleSize = sample })
}

/** Cover art: downloaded for online songs, read from the song file for local ones. Null when there is none. */
private suspend fun loadArt(context: Context, song: Song): Bitmap? {
    ArtCache.cache.get(song.key)?.let { return it }
    return withContext(Dispatchers.IO) {
        try {
            val data: ByteArray? = if (song.artUrl != null) {
                OnlineSources.getBytes(song.artUrl)
            } else if (song.remoteUrl == null) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, song.uri)
                    retriever.embeddedPicture
                } finally {
                    retriever.release()
                }
            } else {
                null
            }
            val bitmap = data?.let { decodeSampled(it) }
            if (bitmap != null) ArtCache.cache.put(song.key, bitmap)
            bitmap
        } catch (e: Exception) {
            null
        }
    }
}

@Composable
fun SongArt(song: Song, modifier: Modifier = Modifier, corner: Dp = 10.dp) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(ArtCache.cache.get(song.key), song.key) {
        value = loadArt(context, song)
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(corner))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center,
    ) {
        val shown = bitmap
        if (shown != null) {
            Image(
                bitmap = shown.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SongRow(song: Song, active: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SongArt(song, Modifier.size(48.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = song.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                text = if (song.source == "Audius") "${song.artist} \u00b7 Audius" else song.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
